(function () {
  "use strict";

  /* ---------- Config ---------- */
  // No backend yet? Keep true so the form still shows a success state.
  // Set to false once /api/booking exists.
  const DEMO_MODE = true;

  const form = document.getElementById("booking-form");
  const section = document.getElementById("booking");
  const checkIn = document.getElementById("checkIn");
  const checkOut = document.getElementById("checkOut");
  const roomSelect = document.getElementById("room");
  const submitBtn = document.getElementById("submit-btn");
  const modal = document.getElementById("success-modal");
  const modalText = document.getElementById("success-text");
  const modalClose = document.getElementById("modal-close");

  /* ---------- Date helpers ---------- */
  function toISO(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  function addDays(iso, n) {
    const [y, m, d] = iso.split("-").map(Number);
    return toISO(new Date(y, m - 1, d + n));
  }
  const today = toISO(new Date());

  // Cannot pick past dates for check-in
  checkIn.min = today;
  checkOut.min = addDays(today, 1);

  // Check-out must be at least one day after check-in
  checkIn.addEventListener("change", function () {
    if (!checkIn.value) return;
    const minOut = addDays(checkIn.value, 1);
    checkOut.min = minOut;
    if (!checkOut.value || checkOut.value < minOut) checkOut.value = minOut;
    validateField(checkIn);
    validateField(checkOut);
  });

  /* ---------- Validation ---------- */
  const rules = {
    fullName(v) {
      if (!v.trim()) return "Enter your full name.";
      if (v.trim().length < 2) return "Name is too short.";
      return "";
    },
    email(v) {
      if (!v.trim()) return "Enter your email address.";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim())) return "Enter a valid email, like name@example.com.";
      return "";
    },
    phone(v) {
      if (!v.trim()) return "Enter your phone number.";
      const digits = v.replace(/\D/g, "");
      if (!/^[+\d\s()-]+$/.test(v) || digits.length < 7 || digits.length > 15) return "Enter a valid phone number.";
      return "";
    },
    checkIn(v) {
      if (!v) return "Pick a check-in date.";
      if (v < today) return "Check-in can't be in the past.";
      return "";
    },
    checkOut(v) {
      if (!v) return "Pick a check-out date.";
      if (checkIn.value && v < addDays(checkIn.value, 1)) return "Check-out must be at least one day after check-in.";
      return "";
    },
    room(v) {
      return v ? "" : "Select a room.";
    }
  };

  function validateField(input) {
    const rule = rules[input.name];
    if (!rule) return true;
    const message = rule(input.value);
    const wrap = input.closest(".field");
    const err = document.getElementById(input.id + "-error");
    wrap.classList.toggle("invalid", Boolean(message));
    input.setAttribute("aria-invalid", message ? "true" : "false");
    if (err) err.textContent = message;
    return !message;
  }

  const requiredInputs = Array.from(form.querySelectorAll("[required]"));
  requiredInputs.forEach(function (input) {
    input.addEventListener("blur", function () { validateField(input); });
    input.addEventListener("input", function () {
      if (input.closest(".field").classList.contains("invalid")) validateField(input);
    });
  });

  /* ---------- Submit ---------- */
  form.addEventListener("submit", async function (e) {
    e.preventDefault(); // handle asynchronously, no page refresh

    const results = requiredInputs.map(validateField);
    if (results.includes(false)) {
      const firstBad = requiredInputs.find(function (i) { return i.closest(".field").classList.contains("invalid"); });
      if (firstBad) firstBad.focus();
      return;
    }

    const data = Object.fromEntries(new FormData(form).entries());
    submitBtn.disabled = true;
    submitBtn.textContent = "Checking...";

    try {
      if (DEMO_MODE) {
        await new Promise(function (r) { setTimeout(r, 800); });
        console.log("Booking payload (demo):", data);
      } else {
        const res = await fetch(form.action, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        });
        if (!res.ok) throw new Error("Server responded " + res.status);
      }
      showSuccess(data);
      form.reset();
      checkOut.min = addDays(today, 1);
    } catch (err) {
      alert("We couldn't send your request. Check your connection and try again.");
      console.error(err);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Check Availability";
    }
  });

  /* ---------- Success modal ---------- */
  function showSuccess(d) {
    modalText.textContent =
      "Thanks, " + d.fullName.trim().split(" ")[0] + ". We're checking the " + d.room +
      " for " + d.checkIn + " to " + d.checkOut + " and will email " + d.email + " shortly.";
    modal.hidden = false;
    modalClose.focus();
  }
  function closeModal() { modal.hidden = true; }
  modalClose.addEventListener("click", closeModal);
  modal.addEventListener("click", function (e) { if (e.target === modal) closeModal(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !modal.hidden) closeModal(); });

  /* ---------- "Book Now" buttons: smooth scroll + preselect room ---------- */
  document.querySelectorAll("[data-book]").forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      if (btn.dataset.room) roomSelect.value = btn.dataset.room;
      section.scrollIntoView({ behavior: "smooth", block: "start" });
      setTimeout(function () { section.focus({ preventScroll: true }); }, 500);
    });
  });
})();
